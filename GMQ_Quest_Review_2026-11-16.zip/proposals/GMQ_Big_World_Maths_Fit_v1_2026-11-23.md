# Algora's deciding years: the maths, fitted to the story

**Date:** 23 November 2026. **For:** Marc, the story thread, and the next reviewer. **From:** the big world thread.
**Read with:** `proposals/GMQ_Algora_Story_v1_2026-11-23.md`.
**Nothing here is built.** Everything is **[Proposal]** unless it says [Source].

**This is version 7.** Five joint reviews have read this note with the story.
- **The first:** "Not yet a base to build on. Close, for one child playing alone." 6 blockers. Section 9.
- **The second,** on the first kind only: **"Not yet. Three blockers, each a small fix. The numbers for the town's stick and promise hold."** Section 9b says what it found and what I did.

**What version 4 changes:** the small row is the same task made smaller; the question names today; both costs are told before the promise; the finished example is about another thing; the engine's path is written out and played in code for 27,000 made-up children; "finished", "a rest" and "decide without me" are defined.

**A third joint review has read version 4: "Not yet. Two blockers, each a small fix. The town's stick, the question and the oil rule hold."** Both blockers were in my picker and my number box. Both are fixed in the check file, and section 9c says how. The fixes have not been reviewed.

**What version 5 changes (23 November, night):** the story thread answered the third review's six points, and its own reviewer then found four story blockers, all fixed (the story, section 16). Version 5 takes the story's words as they are (its section 16c) and follows its section 16d, row by row:
- the seller is a man, the Furrows' tally keeper; his finished example is the last plan of the Year Machine, for the Menders, on count day 9 (no longer a double of the last cut);
- his four lines on cost, said before he asks;
- the small row is **Promise**, a children's game on Market day: reed cups, plums, clay beads; Gran's hooks; shells, by the same rule as the oil;
- the song is taught by the lamp, in the white months of a year already played, so **it costs no year**; a child taught at every band now spends **18 years, not 24**;
- "decide without me" and the second telling use the story's words.
**Version 6 (23 November, later that night)** follows the story thread's second review (its 16h) and its table of differences (16d), row by row. The biggest change: **the seller cannot count ahead, so the only misreading he can see is a promise less than the stick already shows.** He re-asks only then, the same year, on the jetty planks. Any other number runs (section 2). Also: dark lamps, not windows; the small row is **Shells**; the safe way is the last cut; the tally keeper is the town's speaker. **The story thread's round 4 review has not run** (its 16g). Its words may change once more.

**A fifth joint review read version 6 and draft 7: "Not yet."** One blocker: a child put right on the planks who then miscounted was sent down the reading path, so never met Shells or the song. Six majors. **Version 7 and the check file's draft 8 answer all of them** (section 9e). The answers are not reviewed.

**A fourth joint review has read version 5 and the check file: "Both blockers from review 3 are fixed. A base to build on, for one child on one iPad: yes."** No new blocker. It found seven major points and some claims the check file did not check. Section 9d says what I did: all are answered in the check file's draft 6, and in this note.

Every number below comes from `checks/bigworld_year_rule_check.js`. It passes.

---

## 1. What is decided [Source: Marc]

| | Decided | When |
|---|---|---|
| 1 | For now the maths is multiples: "3, 6, 9, 12". A pattern with a start comes later | 23 November |
| 2 | A wrong decision is carried out. Nobody says "wrong". The child sees what follows | 22 November |
| 3 | Then a new problem of the same size | 23 November |
| 4 | His maths skills engine decides a step down. Harder problems come unseen | 23 November |
| 5 | Each child has their own year | 23 November |
| 6 | The simulation is dropped. "Work it logically. I will see how well it works out" | 23 November |

---

## 2. The first kind: how much?

### What the child looks at

- **The tally keeper's stick fills the picture,** at the Lake Market, and stays while the child answers. Four cuts. (The tally keeper is the town's speaker [Built]: to the child, "the speaker".) Each is marked with its count day and the pile that day:

| count day 1 | count day 2 | count day 3 | count day 4 |
|---|---|---|---|
| 6 | 12 | 18 | 24 |

- Nothing is drawn after the fourth cut. The child's own table is in the notebook, and the game fills in none of it.
- The tally keeper never says the step. The child reads it off the stick.

### What the seller says, in this order

1. **A finished example, about another thing.** His old stick, for the oil of one press: four cuts of 20, 40, 60, 80 pots, then the Year Machine's faint scratches ahead, one for each count day, with numbers (100, 120, 140, 160, 180). In the story's words [story, 16c]:
   > "In the last year of the Year Machine, my stick looked like yours: four cuts. The machine scratched on ahead, one count day at a time. It said: promise the Menders this many, on count day 9, after the count. I did. The Year Machine burnt before that day. The oil came anyway, onto every scratch."
   > "I have looked at it a hundred times. I see that it came true. I cannot see how it knew."
   > "That is what the Year Machine did for us. Can you do it without one?"
   - His old stick fills the picture while he speaks. Then the speaker's stick does. The child may ask to see his old stick again; he lays it beside.
   - The answer is 180. No band has a step of 20. **Count day 9, not 8:** 160 was a double of the last cut, which a child could take as the rule [third review]. 180 is not. It is the last three cuts added (40 + 60 + 80), which is a true way; the picker catches a child who has only that habit (section 3).
2. **Both costs, before any number is asked.** In the story's words [story, 16c]:
   > "One pot for each mat you promise, now. One pot fills one lamp for the white months. And one hook on my raft for each mat."
   > "Too few, and the mats with no hook stay on your dock. No pot for them."
   > "Too many, and a hook sails empty. For each, my crew takes two pots back: one for the mat, one for the hook."
   > "For each mat you are out, short or over, one lamp stays dark."
3. **The question, with today in it:**

> "Today is count day 4. My raft comes on count day 7, after that day's count. How many mats will your town have by then, in all?"

**"your town have", not "there be"** [the story's Proposal, 16d row 4]: he deals with three towns, so "there" could mean all of them. Taken. A misreading to watch for with children: "have" read as "have now" (24, the last cut). **24 is what the stick shows, not less, so the seller cannot see it, and it runs** (version 6 said otherwise: the fifth review, M3). It is now a named reading fault: two of them lead to the planks, not to Shells.

The second reviewer found six ways to misread version 3's sentence. Three came from not saying what today is. This one says it, and each cut carries its count day.

### What follows

| | |
|---|---|
| Right (42) | Every hook gets a mat. **No lamp is dark** |
| Too few (said 36) | **Six spare mats on the dock.** Then six dark lamps |
| Too many (said 48) | **Six empty hooks.** His crew takes two pots back for each. Then six dark lamps |
| Far too many (said 99) | His crew takes back every pot. Every lamp is dark: 42 |
| Less than the stick shows (said 18) | **The seller sees it:** "Your stick has more than that already." He lays the stick on the jetty planks, one for each count day: "Here is today. Then this day, and this. Here my raft comes." He asks again, the same year, once. The second number runs. **Put right this way, it is self-corrected** (below) |

- **Before the promise, nothing shows the answer.** It never shows a shelf with 42 places: that would be the answer, drawn.
- **After the promise, the year runs** [Proposal, accepting the story's 16b, finding 17]: the stick gets its new cuts, one each count day; then the dock (spare mats, or empty hooks, which can be counted); then, on raft day, the town sets out one lamp for each mat woven, on the dock at dusk, where they can be counted: "Every mat is a lamp." Those with no oil stay dark. The climb comes after the promise, so it gives nothing away, and it shows the count the child should have made.
- **Six too few costs what six too many costs.** No blind number pays: the reviewer tried "always 99", "always 0", "the last cut", "the next cut".
- A miss of one is one mat on the dock and one dark lamp.
- **A town not yet learned keeps the safe way: the last cut** ("I promise only what I can see") [story, 16d row 6]. On 6, 12, 18, 24 and count day 7 that is 24, so 18 lamps stay dark. It always leaves lamps dark: checked for every problem.
- **The box takes three digits.** No answer is over 99, but a child who means 108 must be able to say 108. The check file tries every number from 0 to 999 for every problem.

### A reply that is a reading, not a count [your engine: classify from both wrong answers]

Code can tell some wrong replies apart with no AI. For 6, 12, 18, 24 and count day 7:

| The child says | What it is |
|---|---|
| 36 or 48 | **A count fault:** one count day short, or one over |
| 18 | **A reading fault:** only the mats still to come. Less than the stick shows, so the seller re-asks |
| 66 | **A reading fault:** seven more count days from today |
| 6, or 7 | **A reading fault:** one day's mats; or the count day itself. Both less than the stick: re-asked |

**Some replies tell nothing:** they are a reading fault and a counting fault at once. On count day 9, 5k is "only the mats to come" and also "the next cut". It happens on count days 6 and 8 too, and on rows like 6 × 6. The check file prints every one. Such a reply does not decide: the child's other reply does [fourth review, M2]. **The sort is the sort of the reply that ran:** a child put right on the planks who then miscounts is a counting fault, and goes to Shells [fifth review, blocker].

**The seller cannot count ahead** [story, 16d row 5]. So the only misreading he can see is a number less than the stick already shows. Then he re-asks, the same year. Any other misreading (66, "seven more count days from today") runs, and the year shows it.

**Put right on the planks is "self-corrected"** [Proposal; fifth review, M2; your engine's own word]. It is not right at the first try. At the first year of a town it lights the town **by a slip**, so the next town asks the same size again. At the gate it is not one of the three answers given alone. So a child who types 0 to see the planks every time gains nothing: in the check file such a child lights towns only by a slip, at the smallest size, and never passes a gate. **Yours to decide** (section 10).

**Gran re-asks too,** at Shells, the same way, when a number is less than the child's own stick shows [Proposal; fifth review, M4]. The story thread has no words for her yet.

Two count faults lead to Shells and the song. **Two reading faults do not:** the next year, the seller lays out the planks **before** he asks. After a missed gate on this path, he lays them out again; nobody sings [fifth review, M1]. The skip counting was never the trouble. **No Shells and no song follow a reading fault** [fourth review, M7]. In the check file, a child who misreads until told is put right on the planks, in the same year, two times in three.

---

## 3. The sizes, and every problem there is

| Band | The step | Who asks |
|---|---|---|
| **Small** | 2, 5 or 10 | the step down: **Shells**, a children's game (below). Your skill map's level below Grade 3 |
| **Low** | 3, 4 or 6 | the first town a child helps |
| **High** | 7, 8 or 9 | the second |
| **Big** | 11 to 15 | later, unseen: "We have more river than Stilt Town." [story, 16d, row 11] |

The reviewer was right that one "full" size from 3 to 9 was too wide: after a miss on 8 × 7 the next problem could be 3 × 5.

**The raft never comes on count day 5.** That is only "the next number". It always comes two or more count days after the last cut.

| | Problems, in a year of 9 gold months |
|---|---|
| Small | 11 |
| Low | 11 |
| High | 12 |
| Big | 12 |

With seven gold months there were 5 or 6 in a band. So the story thread changed its year to nine gold months and three white: twelve, like ours. It is still your decision 2.

### The small row: Shells, the same task, smaller

The second reviewer's first blocker: version 3's small row had no stick, and "one loop for each thing" read two ways (6 bundles, or 30 plums). The third review then found that its cost worked on one side only.

- **It is Shells** (round 2 of the story called it "Promise"), a children's game on Market day: the lake's deal, made small [story, 16a and 16h]. In a step-down year, on Market morning, the cadet sees the speaker off at the town jetty. She says: "This year I promise only what I can see. The dark is my doing, not yours." Then Shells, with a child of the town and their gran. "Let the year run" at Gran's rack shows Gran's count day, raft day and the white months in one run [story, 16h blocker].
- **The thing to count is named,** and counted one by one: lotus pods (two each count day), plums (five), shrimp (ten). Each comes on its own from the family's own pond, tree or trap, so "too many" cannot be undone by making more [story, 16h, finding 11]. Never bundles or pairs.
- **Gran says both costs first, then asks,** in the story's words [story, 16c]:
  > "One shell for each plum you promise, now. And one hook on my rack for each."
  > "Too few, and the plums with no hook are mine for nothing."
  > "Too many, and a hook hangs empty. You give me two shells back for it: one for the plum, one for the hook."
  > "Today is count day 4. I come for them on count day 7, after that day's count. How many plums will there be by then, in all?"
- **It is the oil rule:** one for each promised, two back for each empty hook, never fewer than none. Both sides cost shells, one for each one out. The check file plays it with the same rule.
- **The story thread's caution:** Shells is a game in a game. If a child shrugs at shells, it costs nothing. To check with a child.
- Steps of 2, 5 and 10. Eleven problems.

- **A child never meets a problem twice.** The picker also wishes for a new step, a new count day and a new answer, not the answer the child last said, and not what the child last sang. When no problem left meets every wish, it gives up one wish at a time. Played for 326,164 problems: two running shared a step 5 times, a count day 12 times, an answer twice.
- **It picks by chance** among the problems that meet its wishes [fourth review, M1]. Version 5 always chose the problem that left most others open, so half of all children got 3 × 7 first and half 3 × 9, and an answer could travel round the room. Now 3,000 children get 8 different first problems; the commonest goes to 391 of them. The first problem is never on count day 9, the day of the finished example. Only when 6 or fewer problems are left does it choose the one that leaves most others open.
- **A count day the child has been right on does not come again while another can.** There are three quick ways that are right: add the last two cuts (count day 7), double the last cut (8), add the last three (9). A child who knows all three knows the row. A child with only one of them is right once, and is then asked for another day.
- **Refused,** each printed by the check file with its reason: a row where a wrong method lands on the right answer (3, 6, 9, 12 on count day 6: the last cut plus the count day is also 18); any total over 99; the finished example's own row.
- **"Double the 4th cut" for count day 8 is not refused.** It is a right way, and a good one.

---

## 4. Your engine's steps, in years

[Source: `engines/math-skills/current-v1.1/api/constraints/math-skills.txt`, version 4.1.] The path below is written as code in the check file, and played there.

### In one town

| Step | What happens | Years |
|---|---|---|
| Assess | The town asks at the Market. The cadet promises. The year runs | 1 |
| Right | **Learned.** Lit lamps from then on. At the next New Year the speaker asks: "How did you know?", and listens [story, 16h finding 12] | |
| Wrong, then a new one | Next year the same town asks again: a new stick | 1 |
| Right this time | **Learned,** by a slip | |
| Wrong again: two count faults | Shells, on Market day, in the town. Right: on to the song. Wrong: the song by twos, fives and tens, then Shells once more, on the next Market day. Wrong again: a rest [story, 16b and 16h]. **Shells comes once only:** a child who has passed it in one town goes straight to the song in the next [Proposal; fourth review, M6] | 1 or 2, the first time; then 0 |
| Wrong again: two reading faults | The next year the seller lays out the planks before he asks. After a missed gate, the planks again. **No Shells, no song** | 0 |
| Twice "decide without me" | The singer finds the cadet in the white months: "Come and sing." The song | 0 |
| Taught in single steps, then a worked example | The singer and the cadet make the new verse, one line for each count day, with shells, by the lamp, in the white months of a year already played. **The two rows made this way are the child's own two missed rows.** They use up no new problem | 0 |
| The gate | Three new years, right in a row: **learned.** A miss: that line of the song again, by the lamp, in that year's white months, and one more gate. A second miss: a rest | 2 to 6 |

### Across the three mat towns

| The first town ended... | The next town asks |
|---|---|
| learned at the first try, or through the gate | one band up: low, then high, then big. Nothing is said |
| learned by a slip | the same band once more, as your engine re-asks a fragile skill |
| in a rest | nothing. The kind rests in every town, and your report names the skill |

- **"Learned"** is the word for a town. **"Finished"** is all three towns learned.
- **"A rest"** means: the speakers of towns not yet learned go on promising the last cut, the safe way, and their lamps stay dark. **A learned town stays lit** [story, 16a, point 6]. No town asks again in the trial. The rest of the planet is open.
- **"Decide without me"** is a button at the Market. The speaker promises the last cut, the safe way, and says so. The year runs. After the second in one town, the singer finds the cadet in the white months: "They say you have stopped deciding. Come and sing." [story, 16d, row 6]. **In the code** [Proposal; fourth review, M3]: it uses up its problem, because the child has seen it. The same town asks again next year. Twice at the assess and the probe: the song, then the gate. Once, with one wrong reply: the wrong reply decides the path. At Shells or at the gate it counts as a miss. The speaker promises the last cut, and says so. A child who always presses it ends in a rest after 4 years, so the trial always ends.
- **The picker never repeats a problem.** When it cannot give a problem that is new in step, count day and answer, it gives up one wish at a time: first a count day the child has not been right on, then a new count day, then a new step. Only when every problem of a band is used does it stop. Then a gate with only right answers so far counts as passed.

### Played in code: 3,000 made-up children of each kind

| A child who... | Years for three towns | How the towns ended |
|---|---|---|
| is always right | 3 | all learned at the first try |
| is right 8 times in 10 | 3 to 16. Half need 3 | mostly learned. No band ran out |
| is wrong until taught, in every band | **16** | all three learned through the gate: 6 years in the first town, 5 in each other |
| is taught, but needs a second game of Shells and misses the last question of the first gate, in every town | **26** | all three learned. The longest way a taught child can take |
| misreads ("only the mats to come") until told on the planks | 3 to 7. Half need 3 | the first town by a slip (self-corrected on the planks) or through the gate; then right at the first try |
| always counts one day over | 4 | a rest in the first town |
| always reads "only the mats to come" | 4 | a rest in the first town. Re-asked on the planks whenever the reply is under the stick. **Never sent to Shells:** it is a reading fault |
| only ever adds the last two cuts / doubles the last cut / adds the last three cuts | 4 to 7 | **one town lit at most,** at the first try or by a slip, then a rest. Checked for every child |
| always presses "decide without me" | 4 | a rest in the first town |
| misreads under the stick, is put on the planks, then miscounts | 4 | **Shells** (a counting fault), then a rest. Version 6 sent this child down the reading path |
| types 0 every time, to see the planks | 3 | every town lit **by a slip**, at the smallest size. Never right at the first try, never through a gate |
| reads "have" as "have now" (the last cut), always | 4 | a rest. The planks, never Shells: it is a reading fault |
| reads "N more count days from today", always | 4 | a rest. The planks twice, and never the song |
| presses it, then learns from the song | 15 | all three learned through the gate |
| is right half the time, by chance | 3 to 19 | mixed. A whole band was used up for 1 child in 3,000 |

**Read the third and fourth rows.** A child who must be taught at every band spends 16 years here; one who also needs every second chance, 26. Version 4 said 24, and version 5 said 18. How long a year takes is not known: **time it with children** [story, 16d, row 9]. The story's reviewer finds 18 New Years thin if a child counts them (the story, 16e); 16 is a little less thin.

### Where this bends your engine

| | Your engine | Here | Why |
|---|---|---|---|
| 1 | States the answer after a miss | The year shows it | Your rule of 22 November |
| 2 | Three tries at the gate | Two | **The reason given was wrong** [fourth review, M5]: "two gates need 10" counted the sung rows as problems. With three tries: 17 children in 6,000 who answer by chance use a band up (15 right half the time, 2 right 8 times in 10), and one town can take 13 years, not 10. With two: 1 child in 3,000. **Yours or the threads' to choose again** (section 10) |
| 3 | Picks the skill underneath by judgement | Two count faults: the small row. Two reading faults: told again. Anything else: the small row | Code can see this much. The AI could see more |
| 4 | Stops when the step below is missing | Teaches the step below once, by song | Your words to the main thread: "go down one or two levels... teach that and then work back up" |
| 5 | Assesses a skill once | Three towns, a band higher each time | A town is a place |
| 6 | Confirms or corrects each small step | The singer sings a line again, with shells, by the lamp | She is teaching a song |
| 7 | "Skip", "I don't know" | "Decide without me" | The story's way out |
| 8 | A miss then a right answer is self-corrected | The same, after the planks: a slip, and not one of the gate's three | The seller can see only a promise under the stick |
| 9 | A gate needs three correct answers | If a band runs out mid-gate, the right answers so far count (1 child in 3,000) | A band has 11 or 12 problems |

---

## 5. What the trial would be

| | |
|---|---|
| **One child, on one iPad** | No wall of names. That needs a server, and none has run. [`CLAUDE.md`: each iPad keeps its own game today] |
| **The three mat towns** | Stilt, Reed and Mud. The Menders and the Furrows have no worked "how much" yet (the reviewer's finding 17) |
| **Saved at once** | The stick is saved when a town asks. The promise is saved when it is given. Closing and opening the game brings the same stick back. If the game closes while the year runs, the year is shown again from its start on opening |
| **Closing during a re-ask** | The first number (under the stick) is saved with the problem. Opening the game shows the planks and the question again. The first number is never asked twice [fifth review, M5] |
| **Walking away** | **Once at the lake, the cadet stays** until a number or "decide without me" [story, 16d row 12]. Before that, on Market morning, the cadet may explore. A closed game opens at the same moment |

---

## 6. The maths, against the standards

| What the child does | Standard | How sure |
|---|---|---|
| Reads a row of multiples and goes on with it | 3.OA.9, 3.OA.7 | sure |
| Decides from a table | 3.OA.3 | sure |
| The big band: steps of 11 to 15 | past the tables | a stretch. The reviewer notes it is uneven: counting by 11 is easier than by 7 |

**An honest note, which is decision 1:** on 19 November you said big quests "should require them to actually think and solve and struggle". "How much" is two to five additions. You also chose multiples for now. Both are your words.

---

## 7. Parked: "how many?" and "for how long?"

The reviewer found these further off. I agree. I have not fitted them.

| | The fault | A case |
|---|---|---|
| a | **Neither has a table.** Both are decided at New Year, before any count day. The keeper says numbers and the child divides. That is a sum with a story on top | 24 ÷ 4. 40 ÷ 8 |
| b | **"For how long": too many months is worse than the keeper's own safe way** | She hires for all 7 months and "keeps enough fish back". The cadet says 6 where 5 is right, and the fish jars run out. The town is worse off with the cadet than without |
| c | **"How many": my rule did not model my own question.** With "9 good plots" said aloud, the answer is 9 in five cases, and "9 take away the step" is right in three more | 27 ÷ 3 = 9 |
| d | **The reed side is never told.** A child who sows one plot more "to be safe" is punished by a rule they could not know | |
| e | **A keeper who knows what the store must gain each count day has already counted ahead** | |

**One idea for the story thread, which would give both a table:** the other side brings one. A Furrow carter has a load board: 1 month, 8 blocks. 2 months, 16. 3 months, 24. The child reads on until the wall's number is reached. It is theirs to judge.

---

## 8. What I asked of the story thread, and its answers

All six: **yes.** [The story's section 14.]

| | I asked for | The story now says |
|---|---|---|
| 1 | The rule for too many mats, in its words | One pot for each mat promised, and one hook tied for each. "One pot back for the mat I did not get. One pot back for the hook that sailed empty." Never fewer than none |
| 2 | "On count day N, after the count" | That is now the one way a day is named. Rafts still sail on Last Raft day |
| 3 | A tally stick at the Market | A keeper never leaves home without her stick. She does not say the step: she has never thought of the pile that way |
| 4 | Nine gold months | Its pick now. Your decision 2 |
| 5 | A small row that is small in the story | A child's chore, and gran's rack |
| 6 | The singer as the teacher | Her counting song |

**One thing it asks me to check:** a child may feel "she took two!" as a punishment. If so, its other fair rule is: she takes back one pot, and next year ties only as many hooks as she was given mats. That lasts past New Year, so it is yours. Decision 6.

---

## 8b. What I asked of the story thread the second time. All five: yes [its section 15]

| | | Why |
|---|---|---|
| 1 | **The small row as the town's task, smaller:** a child's own stick, the same question, the thing named (plums, sandals, fire sticks). Both sides cost by the count | The second review's first blocker. Section 3 |
| 2 | **The seller's own stick as the finished example,** and both costs said before the question | Sections 2. Its note has "an old stone", and mats again |
| 3 | **One line on the mats made after the raft has come,** and one on the spare mats | A child will ask. The reviewer did |
| 4 | **Four stale lines:** section 5 still lets the keeper say what comes in each count day; section 3 says "four cuts on the wall", "a step down is a family", and a town asking "at New Year" | They contradict its own rewritten first kind |
| 5 | Old rows on store walls carry no numbers | With three steps in a band, a numbered old row could be this year's |

---

## 9. What the reviewer found, and what I did

| | Found | Done |
|---|---|---|
| B1 | Saying too many mats cost nothing | Section 2: two pots back for each empty hook, with a floor. Checked for every number. The story now says the same |
| B2 | "For how long": too many months contradicts the keeper's safe way | Parked. Section 7b |
| B3 | "How many" and "for how long" have no table | Parked. Section 7a |
| B4 | The "how many" rule did not model its question | Parked. Section 7c |
| B5 | The weakest child's path was a loop of misses with no teaching | Section 4: taught at the small size, then a rest |
| B6 | The wall of names needs a server that has never run | Section 5: left out of the trial |
| | A third of "how much" was only the next number | The raft never comes on count day 5 |
| | "Full" was too wide. One answer could give away the next | Bands. A new answer after every year |
| | The question read four ways | Section 2 |
| | A family made more than a town | The small row is a child's chore now (section 3) |
| | The keeper taught the child | The singer does (section 4) |
| | The years table was short. Engine bends were not stated | Section 4 |
| | The example was not an example of the task | Section 2 |
| | Closing the game and walking away were not designed | Section 5 |
| | My check file claimed more than it did | Rewritten. It now checks the consequences, the picker, and that the note's example is a real problem |

## 9b. The second joint review: three blockers

| | Found | Done |
|---|---|---|
| B1 | **The small row read two ways.** "One loop for each thing": 6 bundles, or 30 plums. And it had no stick | It is the town's task with a child's stick. The thing is named. Section 3. Needs the story thread (8b.1) |
| B2 | **The picker could run dry** after one small row, and its check never tried a change of band | The picker has the child's whole history now. The engine's path is played in code for 27,000 made-up children. It found two more faults of mine, both fixed |
| B3 | **The finished example was the same thing again** (mats, by fives), and its row was the small row's own | The seller's own stick, for oil, by twenties. Section 2 |
| | The question still had six misreadings | "Today is count day 4" is in it. Each cut carries its count day |
| | A fixed habit landed on the answer, and one hit lit a town for ever | The picker does not repeat a count day the child has been right on. Checked |
| | The cost of "too many" was told only after it happened | Told first. Section 2 |
| | The oil shelf gave the answer away, or did not work for "too many" | Only the gap is drawn: dark windows |
| | "Always the small row" ignored what code can see | Reading faults are told again, not sent to the small row |
| | "Finished", the third town, a rest, "decide without me", closing the game: not defined | Sections 4 and 5 |
| | The years table was wrong | Replaced by the played paths. Section 4 |

## 9c. The third joint review: two blockers, both mine

| | Found | Done |
|---|---|---|
| B1 | **A band "ran out" with problems still unused,** and a child who was getting them right was put in a rest. One path could never finish: it needed 12 low problems and there are 11 | The picker gives up one wish at a time and never stops while a problem is unused. The two sung rows are the child's own missed rows, so they use up none. Played again: no band runs out, except for 1 coin-flip child in 3,000 |
| B2 | **Likely wrong replies could not be typed.** "One count day over" for 12 × 8 is 108. In a two-digit box it became 10, and the dock showed the wrong side | The box takes three digits. Checked from 0 to 999 |

**For the story thread, from the same review (not blockers). All six are answered in the story's section 16a, and version 5 of this note follows them:**
1. **The seller counts ahead, and "nobody on Algora can".** Her example says "I counted on: 100, 120, 140, 160." A child can ask why she does not read the keeper's stick herself.
2. **Her example lands on a double** (80, then 160). A child may take "double the last cut" from it. Count day 6 or 9 would not.
3. **The cost of too few is not said as a cost.** "Mats with no hook are no use to me" is her loss, and the story adds "nobody is worse off for a mat". Before the promise, saying less sounds safe.
4. **"A cousin with no plum" costs nothing on the plum side.** Saying 99 loses no plums. And Gran does not say either cost before she asks.
5. **Where does a sung year happen?** The Market is at the lake. The singer is in a town.
6. **A rest: does it darken towns already learned?** My note said "in every town". The story says lit windows "from then on". The story is right: a learned town stays lit.

**Mine, still open:** a reading fault fails the small row for the same reason, because it is the same sentence. "Decide without me" is not in the code yet.

**Not done:** the class picture (the reviewer's finding 18). With no server there is nothing to build. It stays a question.

## 9d. The fourth joint review: "yes, a base to build on"; seven major points

| | Found | Done |
|---|---|---|
| M1 | **The picker was almost fixed:** half of all children got 3 × 7 first, half 3 × 9 | It picks by chance among its wishes. 8 different first problems; the commonest for 391 of 3,000. Checked |
| M2 | **Reading faults went down the wrong path** on count day 9 (5k and 10k are both kinds) | Such a reply tells nothing; the other decides. "Only the mats to come" never goes to Promise. Checked for every child |
| M3 | **"Decide without me" was not defined** | Defined, in the code and section 4 [Proposal]. Two kinds of child play it; both finish |
| M4 | **"18 years" was a range, up to 30** | Now 16 to 26 (section 4) |
| M5 | **The reason for two gate tries was wrong** | Said so; the cost of three is printed every run (section 4, row 2 of the engine table) |
| M6 | **Promise came back in every town** | Once only [Proposal]. For the story thread: the errand ("find what we have lost") is said once |
| M7 | **The note and the code disagreed on the song** | The code follows the note: a reading fault gets the jetty telling, no song |
| | The file claimed "never" for shared steps, days and answers | It prints how often (above), and says "wishes" |
| | "No fixed habit was waved through" counted first tries only | It counts every town lit: one at most. Checked |
| | "Add the last three cuts" was not played | It is now: one town at most |
| | Which path a child takes was never checked | Each kind names its path, and it is checked |
| | `most <= 12` could not fail | It is `most <= 10`, the longest a town can take with two tries |
| | The gate's first problem could match what was just sung | After the song, the picker counts the last sung row as the last row |

**Version 6, after the story's second review:** the re-ask on the planks only when the reply is under the stick; the next year's planks before the question for a reading fault; the safe way is the last cut; Shells, with lotus pods, plums and shrimp; lamps, not windows; "your town have". All in the check file's draft 7, which passes. **Not reviewed yet.**

**Still open, small:** a short gate passes when a band runs out (1 child in 3,000; listed as an engine bend here); "one count day over" may be a misreading of "after that day's count" (watch for it with children); the second Promise year has no New Year line (for the story thread).

**Mine, from before, now closed:** a reading fault no longer meets Promise, so it cannot fail it for the same sentence; "decide without me" is in the code.

## 9e. The fifth joint review: "Not yet"; one blocker

| | Found | Done (check file draft 8) |
|---|---|---|
| B1 | **A child put on the planks who then miscounted went down the reading path:** no Shells, no song | The sort is the reply that ran. A kind of child that does this is played: it reaches Shells |
| M1 | **The reading path was told "that line of the song again"** after a missed gate | It is the planks again. Checked: a reading path never meets the song |
| M2 | **Put right on the planks counted as right at the first try.** Typing 0 got free help every year | Self-corrected: a slip, and not one of the gate's three [Proposal; yours] |
| M3 | **The note said 24 is under the stick.** It is not | Said so. 24, the last cut, is a named reading fault |
| M4 | **A mixed child failed Shells on a misreading** Gran could not see | Gran re-asks under the stick too [Proposal; for the story thread] |
| M5 | **Closing the game during a re-ask** was not defined | Defined (section 5) |
| M6 | **Planks for a misreading he cannot see** (66) | Kept, because your engine can see it. **For the story thread:** he did see the year go wrong (empty hooks, spare mats). Is that his reason? |
| | Claims: refused rows not printed; paths checked in the first town only; the re-ask had no checks; the first problem rule not checked | All printed or checked now |
| | Two first problems shared the answer 24, so an answer could travel | A first problem's answer is no other first problem's: 6 first problems, all different answers |
| | After the song, the gate avoided only the last row sung | It avoids both |

**For the story thread, from the same review:** why does the seller accept a second number that is still under the stick? And his jars: the code assumes they hold at least twice what any town makes (then "the crew takes it all back" and the oil rule agree).

---

## 10. Your decisions

Both reviewers said the two notes hold more decisions than a person can answer. The second said the threads could simply decide four of mine. So I have, and they are listed under the table. These four are left.

| | Decision | Options, with costs | I would choose |
|---|---|---|---|
| 1 | **Is "how much" enough for a first big quest?** | **Decided [Source: Marc, 23 November, to the main thread]: "how much" is fine as the first big quest.** Two or three children try Algora this week | |
| 2 | **One right year lights a town for good** | **Decided for the trial [Source: Marc, 24 November, to the story thread: "Ok. I agree. Proceed"; the story note's 16j]: yes, one.** Yes, as your engine passes a skill on one right answer. Or two right years on different count days: surer, and twice as long for every child | one |
| 3 | **A child who must be taught at every band spends 16 to 26 years** (24 in version 4; 18 in version 5) | **Decided for the trial [Source: the same]: accept it, and time it.** Accept it for the trial, and time it. Or teach once only, and after that a miss is a rest | accept, and time it |
| 4 | **Put right on the planks: is it learned?** | **Decided for the trial [Source: the same]: a slip.** A slip, as your engine says "self-corrected" (the next town asks the same size; at the gate it does not count). Or right, as if at the first try: faster, but a child can type 0 for free help | a slip |

**Decided by the two threads, as you said we should. Say if you disagree.**
- **Nine gold months.** You said: "however long you make their year."
- **Two tries at the gate,** not your engine's three. **Open again:** its reason was wrong (section 4, "Where this bends your engine", row 2). Three tries costs a band running out for 17 children in 6,000 who answer by chance, and up to 13 years in one town. I would still choose two, now for that reason.
- **The singer may sing a wrong line again.** Your engine corrects in teaching too.
- **Two pots back for an empty hook.** The other way lasts into the next year.
- **The step down:** the small row for count faults, a second telling for reading faults.
- **The trial has no class view.** No server has run.
