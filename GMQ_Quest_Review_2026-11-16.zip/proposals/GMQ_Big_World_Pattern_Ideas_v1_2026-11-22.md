# Patterns on Algora: a bank of ideas

**Date:** 22 November 2026, night. **For:** Marc. **From:** the big world thread.

**What this is:** kinds of pattern, ways to show them, and things on the planet that could carry them.
**What this is not:** a quest design. No quest is designed here. Nothing is built.

Everything is **[Proposal]** unless it says [Source]. Every number in the examples was worked out again.

---

## 1. First, a plain fact

**Algora is in Galaxy Patternox, and almost nothing built on it is a pattern.**

| Built | Is it a pattern? |
|---|---|
| The four machines | A rule: in and out. Close to patterns, but the child never sees a sequence |
| The stepping stones | Yes: go on with a number pattern. One kind only: the same step each time |
| The loose cog | A rule from two pairs |
| The fleet | No. Times tables |
| The well | No. Times tables |

You were right to stop me. I was building multiplication with a pattern name on it.

---

## 2. What I read

| Source | What it gave |
|---|---|
| Exemplars | **Their task library needs a login. I could not read it.** On open pages I found one Grade 3 task (a Lego tower where each level is a multiple of the one below; children may use a table, a drawing, a number line or real bricks), and mentions of two more: stones collected over days, and birds seen each day for a week, both solved with a table. **If you can paste or name the Exemplars tasks you like, I can work from those** |
| Illustrative Mathematics, Grade 4, "Patterns that repeat" | Repeating shapes, then: "what is the 31st shape?" Children number the shapes, and each shape becomes a list of numbers: multiples |
| Illustrative Mathematics, the four 3.OA.9 tasks | Patterns inside the addition table and the times table, and why they happen |
| youcubed, the Raindrop task | Growing shapes. The first question is not "how many?" It is "**How do you see it growing?**" Children see it in many ways, and every way is right. The table comes after |
| NRICH, patterns for ages 5 to 11 | Stick triangles that grow by layers; necklaces; a times table that has been shifted; two plants, and the day they are the same height |
| Research on young children and functions (Blanton and others) | See section 6 |
| A music lesson (Kennedy Center), Stanford's early maths group | A rhythm is a repeating pattern. The same pattern can be clapped, then drawn |

**Could not read:** the Exemplars library; one Exemplars scoring page (the site was down); a teachers' textbook chapter on patterns (refused).

---

## 3. The kinds of pattern

| | Kind | A small example | The question that makes it maths |
|---|---|---|---|
| A | **Repeating** | red, gold, gold, red, gold, gold | What is the part that repeats? What is the 24th? |
| B | **Repeating, two things at once** | Colour goes red, blue. Shape goes round, square, star | When is it a red round one again? (Every 6th) |
| C | **Growing by the same step** | 5, 8, 11, 14 | The 10th? Which place holds 35? |
| D | **Shrinking** | 60, 56, 52, 48 | When is it gone? |
| E | **Growing by more each time** | 1, 3, 6, 10, 15 | How much is added each time? What is the pattern in *that*? |
| F | **Doubling, or times each time** | 1, 2, 4, 8, 16 | When does it pass 100? |
| G | **A growing shape** | squares stacked like steps | How do you see it growing? Then: the 7th? |
| H | **Two things that change together** | day 1: 4. Day 2: 7. Day 3: 10 | What is the link between the day and the number? |
| I | **Patterns inside the number tables** | every answer in the 4 times table is even | Why? |
| J | **Cycles in time** | one sun is high every 3rd day, the other every 4th | When are both high? (Day 12, day 24) |
| K | **Two rules taking turns** | 2, 5, 4, 7, 6, 9 (add 3, take 1) | What are the two rules? |
| L | **Two patterns woven together** | 1, 10, 2, 20, 3, 30 | Pull them apart |
| M | **Patterns in space** | a mirror pattern on a mat; tiles on a floor | What goes in the missing corner? |
| N | **Patterns you hear or do** | clap, stamp, stamp | Show the same pattern with colours |
| O | **A broken pattern** | 3, 6, 9, 13, 15 | Which one is wrong? |
| P | **Not a pattern yet** | 2, 4, ... | It could be 6. It could be 8. What else must you know? |

**About P.** Two numbers do not make a pattern. This is the fault my reviewers kept finding in other words: "it can be read two ways". For patterns it is not a fault to hide. It is a thing to teach.

---

## 4. What a child can *do* with a pattern

Going on with a pattern is only the first thing. There are eleven more.

| | The child... | An example |
|---|---|---|
| 1 | goes on with it | the next three |
| 2 | fills a gap | 4, 8, __, 16 |
| 3 | finds the mistake | one lantern on the bridge is the wrong colour |
| 4 | says the rule in words | "it goes up by 3, and it starts at 5" |
| 5 | **jumps far ahead** | the 24th day, with no list to count along |
| 6 | **goes backwards** | "which day has 35?" |
| 7 | asks "will it ever?" | "will the count ever land on 45?" |
| 8 | **makes one** for someone else to go on with | a villager must be able to continue it |
| 9 | **shows it another way** | hears a drum pattern, lays it out in shells |
| 10 | compares two | which reaches 50 first? On which day are they the same? |
| 11 | sorts | which of these belong to the pattern? |
| 12 | says why | why is 4 times anything always even? |

- **5 and 6 are what your "24th day" is about.** Section 6 says why they matter.
- **8 and 9 are the ones where a child makes something.** They are also the ones a typed world is good at: the child types or lays out a pattern, and a villager tries to go on with it.

---

## 5. Ways to show a pattern

| Way | Good for | A caution |
|---|---|---|
| **Things in a row** (beads, lanterns, rafts) | repeating, two things at once, the mistake | A long row can be counted along. For "the 24th", show only the first 8 |
| **A growing shape** | seeing growth in more than one way | Draw it so that more than one way of seeing is possible |
| **A table the child fills** | two things that change together; the far jump | See below |
| **A path with jumps** (a number line as a road, stones, a ladder) | the same step; going backwards | |
| **A hundred board with colour** | skip counts; "will it ever land on 45?"; diagonals | |
| **A wheel** (a sky wheel, a calendar ring) | cycles. Going round and round shows why the 24th is like the 3rd | |
| **Two wheels, or two rows, side by side** | two cycles lining up | |
| **Sound** | repeating. Algora already makes its music in code: a tune *is* a pattern, and the page could play one for the child to catch | Needs a way to see it too, for a quiet room |
| **A creature's tracks** | hop, hop, jump: a pattern to follow across the map | |
| **Heights side by side** (plants, towers, the tide post) | growing and shrinking; comparing two | |
| **Cloth and weaving** (over, under) | patterns in space; two things at once | |

### The table, and the 24th day

- **A table with every row** (day 1, 2, 3, 4, 5...) lets a child just add down the column. To reach day 24 that is 23 additions. It works, and it is slow.
- **A table that skips** (day 1, 2, 3, then 10, then 24) cannot be done by adding down. The child must look *across*: what links the day to the number?
- **The child's own table in the notebook** is better than a table the game draws. The child decides which days to write down. [The notebook already holds the machines' tests.]
- **24 and 28 are good numbers.** 24 is a multiple of 2, 3, 4, 6, 8 and 12. 28 is a multiple of 2, 4, 7 and 14. So "the 24th" lands on the end of the repeating part for many patterns, and "the 28th" for a 4 or a 7.

---

## 6. What the research says, in four points

1. **Children first think "add 3 each time".** That is thinking down the list. It works for the next one. It is slow for the 24th.
2. **"The number is 3 times the day, and 2 more" is a different thought.** It links two things. Far-ahead questions and backwards questions are what move a child from the first thought to the second. So the 24th day is not just a bigger number. It asks for a better idea.
3. **For a repeating pattern, the key is to name the part that repeats.** Then number the places. Every gold lantern is at a multiple of 3. Patterns and times tables meet here.
4. **For a growing shape, ask "how do you see it?" before "how many?"** There are many right ways to see it. Each way gives a different sum for the same answer.

**Grade levels, plainly:**
- Patterns in the number tables, and saying why: Grade 3 (3.OA.9).
- Making a pattern from a rule and noticing what the rule did not say: Grade 4 (4.OA.5).
- "The 31st shape" of a repeating pattern: I found it in a Grade 4 lesson. With a repeating part of 2, 3 or 4, and a place that is a multiple, I think Grade 3 can do it. **That is a guess. You know your class.**
- Growing by more each time, and doubling: a stretch.

---

## 7. Things on the planet that could carry a pattern

Not quests. Only: this thing is on Algora, or could be, and this is the kind of pattern it would show well.

### The sky and time

| Thing | Kind | The idea |
|---|---|---|
| **The two suns** [built: they are in every sky] | J, cycles | The gold sun is high every 3rd day. The white sun every 4th. Both are high on day 12 and day 24. A festival falls on those days |
| **An Algora week** | A, repeating | A week of 6 named days. What day is day 24? (The last day of week 4.) Day 28? (The 4th day of week 5) |
| **The tide post in the Reach** | C and D | The water climbs 3 marks a day, from mark 5: 5, 8, 11. Day 10 is mark 32. It reaches mark 35 on day 11 |
| **A water clock** | D, shrinking | 60 drops, 4 fewer each day. 24 are left after 9 days. It is empty after 15 |
| **Fireflies in the Woods** | J, heard or seen | One blinks every 2 beats, one every 3. When do they blink together? |

### Things that grow

| Thing | Kind | The idea |
|---|---|---|
| **A fast vine** | F, doubling | 1 leaf, 2, 4, 8. Day 7 has 64. Day 8 passes 100 |
| **A caterpillar** | C, with a start | 3 parts on day 1, one more each day. Day 24 has 26, not 24 |
| **The terraces** | E and G | Stones in steps: 1, 3, 6, 10, 15, 21, 28. The 7th is 28. Seen two ways: "one more row each time", or "a staircase" |
| **Tree rings** | H | One ring a year. Count the rings: how old? |
| **The Growing Dunes** [in the design: Grade 4] | G | A dune's shape in squares. How do you see it growing? |
| **Two plants** | 10, comparing | One starts tall and grows slowly. One starts short and grows fast. On which day are they the same? |

### Things people make

| Thing | Kind | The idea |
|---|---|---|
| **Lanterns on a bridge** | A, and O | Red, gold, gold. The 24th is gold. 16 of the first 24 are gold. One is wrong: find it |
| **Sails in the fleet** | B, two things at once | Sail colour goes one way, sail number another |
| **The net weaver's mats** | M | Over, under, over. A mat with a hole: what goes in it? A child can design a mat |
| **Bead belts** | A, 8, 9 | The child makes one. A villager must be able to go on with it |
| **The Menders' machines** | N | Each machine chimes a pattern. The cog that fell out left a gap in the chime |
| **A growing song** | E | Verse 1 has 1 line. Verse 2 has 2. After 7 verses the singer has sung 28 lines |
| **Drum calls between towns** | N, 9 | A town drums a pattern. The child sends it on with flags |
| **The pip store** | 10 | Two offers of pay. 2 pips, then 4, then 6. Or 10 every day. The first pays more from day 6. In all, they are level after 9 days (90 each) |
| **The Furrows' quilts and crop rows** | A, M | Beans, gourds, rest. Which crop is in the field in year 8? |
| **Gears in the Old Works** | J | A wheel of 3 teeth turns a wheel of 4. When is the red tooth back at the top? (After 12) |

### Things in the wild

| Thing | Kind | The idea |
|---|---|---|
| **Tracks** | A, as a trail | Hop, hop, jump. Follow the pattern through the mist to where the creature went. A wrong guess leads to a dead end |
| **The birds on the old wall** [the hedge is built, and says "knock the way the woods count"] | N | They tap a pattern. The hedge opens to it |
| **A striped snake, a beetle's spots** | A, B | A creature half hidden in grass: what is the rest of it? |
| **Mile posts on the road** | C, 2 | Posts numbered in jumps. One has fallen over |
| **Stones in the sea by the Prime Isles** [Grade 4] | I | Colour every 2nd stone, every 3rd, every 5th. Which are never coloured? |

### The Gate itself

| Thing | Kind | The idea |
|---|---|---|
| **The Gate's flicker** | A, K | It flickers in a pattern. A broken Gate flickers wrongly. This could be what "broken" *looks like*, from the first page of the story |
| **The number boards on its mountain** | I | The addition table and the times table, cut in stone, with gaps. Why is this diagonal all doubles? |

---

## 8. Five ideas I think are the freshest

1. **A pattern is a thing you can hear.** The page already plays tunes made in code. No other part of the game can do this.
2. **The child makes the pattern, and the world must be able to go on with it.** Then the child is the one who knows the rule.
3. **Two cycles that line up.** Two suns are already in the sky. Nobody has asked what they are for.
4. **"Not a pattern yet."** A villager shows two numbers and asks what comes next. The right reply is "I cannot know yet. Show me one more." It turns my reviewers' hardest fault into a lesson.
5. **Tracks through the mist.** The map is big and mostly dark. A pattern could be the way to cross it.

---

## 9. Cautions, from this week's reviews

- **Enough of the pattern must show** for one reading only. Or the child can ask the world for more ("show me another day"), as with test pebbles in a machine.
- **Tapping the next number from three choices is guessing.** Typing it, or laying it out, is not.
- **A long row lets a child count along.** Then "the 24th" needs no thinking.
- **A table the game fills in does the work.** The child's own table does not.
- **More than one way of seeing a growing shape is right.** The world must accept them all.

---

## 10. What could prove these ideas wrong

- **Your class may find repeating patterns babyish.** They are Kindergarten work until the far jump is asked.
- **Sound in a classroom of 14 iPads** may be noise.
- **I have read about Exemplars tasks, not the tasks.** Yours may do something none of this does.
- **"Grade 3 can find the 24th" is my guess.**
- **Nobody has tried any of it.**

---

## 11. What would help me next

1. **Which kinds do you want?** Tick the rows in section 3.
2. **Which Exemplars tasks do you use?** A title is enough. Or paste one.
3. **Has your class met repeating patterns with a far jump? Tables?**
4. **Sound: yes or no?**

Then I design, on paper first, with a review before any building.

---

## 12. Your belief, the evidence, and where I push back

[Source: Marc, 22 November, late] "Most things do become patterns... we need a lot about patterns and making tables and making visual presentations to always show them, because that leads to the other math." You asked me to research it and push back.

### Where the research agrees with you

| Your claim | What I found |
|---|---|
| Patterns lead to other maths | 517 children were followed from age 4 to age 11. What they knew about patterns at 4 predicted their maths in Grade 5. What they knew about shapes did not. [Rittle-Johnson and others, 2016] |
| Teaching patterns helps | First graders taught patterns for 15 minutes, three days a week, for six months did better in maths than children taught other things. Children were assigned by chance. [Kidd, Pasnak and others, 2014] |
| It works in Grade 3 | Third graders had 23 lessons on rules, tables and the equals sign. They beat the other classes, and used better methods. The first study was small: 39 children against 67. A larger one later agreed. [Blanton and others, 2015] |
| Tables and pictures help | A United States government guide for Grades 4 to 8 recommends them. A table or a diagram links what is in the problem to the sum that solves it |

So the core of what you believe has support.

### Where I push back

**1. The strong evidence is for young children and simple patterns.**
- Most of it is ages 4 to 7, and repeating patterns.
- Much of the teaching evidence comes from one research group.
- In 2008 a United States national panel said patterns are "not a topic of major importance".
- **For Grade 3, what has support is one step: from "what comes next" to "what links the day to the number".** More "what comes next" has none that I found.

**2. "The times table is patterns, because it is skip counting." Half.**
- Skip counting is a pattern. Yes.
- But researchers treat it as a step on the way, and some children never leave it. They can say 3, 6, 9, 12 and not know that it also tells *how many threes*.
- Knowing times tables means seeing groups of groups. That is more than a list.
- **And my fleet does not use the pattern at all.** It asks: what times 8 is 72? A child who knows the fact types it. A child who does not, guesses. Nobody looks at a table and notices anything.
- For the times table to be pattern work, the child must look, notice, and say why. "Every answer in the 4s is even. Why?" That is Grade 3's own standard (3.OA.9).
- So I would not let the fleet off as "patterns".

**3. "Always make a table." A table can stop the thinking.**
- A teacher named Dave Hewitt called it a "train spotters' paradise": children look down the column, spot "+3", and rush on. They no longer think about the thing the numbers came from.
- The table must stay tied to the picture. And the question must be one the column cannot answer: the 24th, or "which day?", or "why?"

**4. "Most things become patterns." Seeing a pattern is not knowing why.**
- A pattern from three cases can be false.
- So two things belong beside every pattern: "why does it go on?" and "is it a pattern yet?"

**5. Pictures help when the child makes them.**
- Being shown a picture is weaker than building one.
- More ways of showing are not always better. Each new way must be learned, and the child must be helped to link them.

### Your belief, sharpened [Proposal]

> Patterns, tables and pictures lead to the other maths **when the child makes them, links them to each other, and says why.**

### What could prove me wrong

- I read summaries and abstracts tonight, not the full papers.
- I could not read Hewitt's article itself, only its first lines.
- You have watched Grade 3 children for years. I have not watched one.

---

## 13. Exemplars: your plan to log in and let a Claude session look

It would help. Three cautions first.

1. **Their tasks are paid for, and they own them. Our folder and website are public.** So the session should bring back ideas, not text: no task wording, no student work, no pictures. Nothing of theirs goes into this folder.
2. **Their rules may not allow a program to click through the library.** I do not know their terms. A safer way: you filter the library by patterns and algebra, open the tasks you like, and the session reads only the pages you open.
3. **This session cannot use your browser.** It runs in the cloud. A session on your own computer can. Never type the password into a chat.

### A brief you can paste to that session

> Look only at the pages I open. For each Exemplars task in Grades 2 to 5 that is about patterns, rules, tables or things that grow or repeat, write one row, in your own words:
> - title, grade
> - what grows, shrinks or repeats, and by how much
> - the kind of pattern: repeating; two things at once; the same step; shrinking; more each time; doubling; a growing shape; two things that change together; a cycle; two rules; other
> - what is asked: the next one, a far one (which?), a backwards one, a comparison, "why"
> - what the child is expected to make: a table, a drawing, a number line, a model
> - anything unusual
>
> Do not copy any sentence of a task. Do not copy student work or pictures. Save the table on my computer only.

Then paste the table to me.

---

## 14. Your rule for mistakes: let it happen

[Source: Marc, 22 November, late] "That is what our story problems can do. They have the table, they must analyze it and make a decision based on it... how much stone do we need in the 12th month if this growing pattern continues. And they make a mistake, we shouldn't say no that's not right. We should let it happen, and they will see negative consequences of it... then we step back to an easier scaffolding... a different problem, a smaller one, and they can see that it does work... then even you go back to the harder one and maybe even go one past that."

It also fits what you said before: "Your decisions must matter" (17 November), and "no chance to struggle" (19 November).

### The rule, as six steps

1. **A story problem with a table.** The child reads the table and makes a decision. ("We need this much stone by month 12.")
2. **The world does what the child decided.** Right or wrong. Nobody says "that is not right".
3. **What follows can be seen.** The dam is too low and the river comes over. There is not enough food by the 3rd month.
4. **The child chooses:** go on with the quest, or step down.
5. **The step down is an easier problem of the same kind:** smaller, and different. It works, and the child sees it work.
6. **Back to the hard one. Then, maybe, one past it.**

### Two things this answers

- **My pushback on tables** (section 12, point 3). A table read for a decision is not train spotting. The decision is the question the column cannot answer. You are right.
- **My open question to you:** "easier numbers, or more help, for a child who struggles?" Your answer is neither. First what follows from the mistake, then a smaller problem, then back.

### What is built does the opposite

| Where | What the page does now |
|---|---|
| A machine's plate | A wrong plate falls off at once |
| The pan on the bridge | The bridge stays up |
| The stepping stones | A splash, and back to the bank |
| The fleet | A red lamp. **Nothing sails until every line is right** |
| The net weaver | "That does not come to 18" |
| The reed cutter | "No. Ten reeds in every bundle. Count again" |
| The Makers' box | "Not the rule yet" |

- Every one of these says "wrong" at the moment of the answer, in kinder words.
- **In the fleet I took the consequences out on purpose.** A reviewer showed that a town served early could make the job impossible. I answered by letting nothing happen until all was right. Your rule answers it the other way: let the rice go to the wrong town, show what follows, and give a way back.
- **I also gave my reviewers a rule that was mine, not yours:** "the world never accepts wrong maths". By your rule the world does accept it, and shows what it leads to. I withdraw that rule.

### What the research says

- **Trying a problem before being taught, and failing, helps.** A review of 53 studies found children learn more this way than when they are taught first. Two conditions: the child must know enough to make a real try, and a clear look at what works must follow. Your step down is that second part. [Sinha and Kapur, 2021]
- I could not find whether it holds as well for 8-year-olds. The studies run from school age to university.
- **"Right" and "wrong" marks can feel like being judged.** One study warns of this. The evidence on kinds of feedback is mixed. [A 2024 study of children's maths feedback]

### What the rule asks of any design. Questions, not answers.

| | The question | Why it matters |
|---|---|---|
| 1 | **Can the child always come back?** | A flooded town must not end the quest. A new season, a second wall, a rescue |
| 2 | **Does what follows come from the child's numbers?** | If every mistake gives the same flood, it is "wrong" with a picture. The dam should be short by what the child was short |
| 3 | **Then the next try must be a different problem.** Your words: "a different problem". | If the dam is 6 too low and the same problem comes back, the child adds 6 and has learned nothing |
| 4 | **Soon enough to link.** | If month 12 comes ten minutes later, the child will not tie the flood to the table. The child's own table should be on the screen when it happens |
| 5 | **What is under the easy step?** | A child who fails the smaller one too needs a floor: a finished example, or a villager who does one alongside |
| 6 | **Three sizes of every problem, for every child.** | Smaller, the one, one past. Code can make them and check them on thousands of children. The AI tells what follows; the code holds the numbers. That is your constraint design |
| 7 | **Failing on purpose.** | A flood is fun to watch. That is fine once. Getting it right must be the better show |
| 8 | **Lesson time.** | A mistake now costs a consequence, a smaller problem, and a return |
| 9 | **What the report keeps.** | The first decision, what followed, whether the child stepped down, and the return. That tells you more than a score |

### Four things only you can say

1. **When the child goes back to the hard one, is it the same problem or a new one of the same size?** (Row 3 says new. Your call.)
2. **Is stepping down always the child's choice?** Or does the world offer it after two failed tries?
3. **"One past": does it earn something more,** a better card?
4. **What is built: change it to this rule, or leave it and use the rule from here on?** Changing the fleet is the biggest piece.

---

## Sources

- [Exemplars: K to 5 sample tasks](https://exemplars.com/sample-performance-tasks/math-samples-k-5)
- [Exemplars: third grade tasks and the rubric (the Lego task)](https://exemplars.com/blog/supporting-teks-mathematical-processes-exemplars-performance-tasks-and-rubric-third-grade)
- [Exemplars: getting started guide](https://exemplars.com/sites/default/files/2026-02/Exemplars_Getting_Started_Web_2026.pdf)
- [Illustrative Mathematics, Grade 4, Unit 6, Lesson 2: Patterns that Repeat](https://im.kendallhunt.com/k5/teachers/grade-4/unit-6/lesson-2/lesson.html)
- [Illustrative Mathematics: tasks for 3.OA.9](https://tasks.illustrativemathematics.org/content-standards/3/OA/D/9/tasks.html)
- [youcubed: the Raindrop task](https://www.youcubed.org/wp-content/uploads/2018/09/Raindrop-Task-final-copy.pdf)
- [NRICH: describing patterns and sequences](https://nrich.maths.org/tags/describing-patterns-and-sequences)
- [NSW Department of Education: exploring patterns](https://education.nsw.gov.au/teaching-and-learning/curriculum/literacy-and-numeracy/teaching-and-learning-resources/numeracy/patterns)
- [Cambridge Mathematics: developing concepts of pattern](https://www.cambridgemaths.org/Images/espresso_47_developing_concepts_of_pattern.pdf)
- [Cambridge Mathematics: early development of functional thinking](https://cambridgemaths.org/Images/espresso_48_early_development_of_functional_thinking.pdf)
- [Ontario curriculum, Grade 4: patterns and relationships](https://www.dcp.edu.gov.on.ca/en/curriculum/elementary-mathematics/grades/g4-math/strand-c/c1)
- [McEldoon and Rittle-Johnson: function tables in Grades 2 to 6](https://cdn.vanderbilt.edu/vu-sub/wp-content/uploads/sites/280/2023/08/02221827/ATME_McEldoonandRittle-JohnsonPME-NApaper_2010.pdf)
- [Virginia Department of Education: Grade 3 plan on patterns](https://doe.virginia.gov/home/showpublisheddocument/16916/638037105276000000)
- [Mathnasium: patterns on a hundred chart](https://www.mathnasium.com/math-centers/lajolla/news/hundred-chart-number-patterns)
- [Kennedy Center: composing and clapping rhythms, Grades 3 to 5](https://www.kennedy-center.org/education/resources-for-educators/classroom-resources/lessons-and-activities/lessons/3-5/composing-and-clapping-rhythms/)
- [Stanford DREME: seeing patterns in music](https://dreme.stanford.edu/?p=3240)
- [Rittle-Johnson and others: early maths knowledge and later achievement (Vanderbilt news)](https://news.vanderbilt.edu/2016/12/06/early-math-knowledge-related-to-later-achievement/)
- [Kidd, Pasnak and others: instructing first-grade children on patterning](https://nssa.stanford.edu/studies/instructing-first-grade-children-patterning-improves-reading-and-mathematics)
- [Blanton and others, 2015: an early algebra intervention in third grade](https://nctm.org/Publications/Journal-for-Research-in-Mathematics-Education/2015/Vol46/Issue1/The-Development-of-Children_s-Algebraic-Thinking_-The-Impact-of-a-Comprehensive-Early-Algebra-Intervention-in-Third-Grade)
- [Does early algebra matter? Grades 3 to 5](https://cadrek12.org/resources/does-early-algebra-matter-effectiveness-early-algebra-intervention-grades-3-5)
- [Institute of Education Sciences: Improving Mathematical Problem Solving in Grades 4 Through 8](https://ies.ed.gov/ncee/wwc/practiceguide/16)
- [Victoria Department of Education: additive and multiplicative thinking](https://www.education.vic.gov.au/Documents/school/teachers/teachingresources/discipline/maths/assessment/additivemulti.pdf)
- [Jacob and Willis: the development of multiplicative thinking](https://merga.net.au/wp-content/uploads/DOCS/common/Uploaded%20files/Annual%20Conference%20Proceedings/2003%20Annual%20Conference%20Proceedings/RR_jacob.pdf)
- [Dave Hewitt: Train Spotters' Paradise (on NRICH)](https://nrich.maths.org/node/56112)
- [Sinha and Kapur, 2021: when problem solving followed by instruction works (summary)](https://phys.org/news/2021-09-productively-wiser.html)
- [Fyfe and Rittle-Johnson, 2015: feedback and children's prior knowledge](https://news.vanderbilt.edu/files/FyfeRittleJohnson2015_JEP.pdf)
- [A 2024 study of right and wrong judgments in children's maths feedback](https://pmc.ncbi.nlm.nih.gov/articles/PMC10923023)
